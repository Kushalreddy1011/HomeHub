import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="logo">
        🏠 HomeHub
      </Link>

      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/?category=Furniture">Furniture</Link>
        <Link to="/?category=Kitchen">Kitchen</Link>
        <Link to="/?category=Electronics">Electronics</Link>
      </div>

      <input
        className="search"
        placeholder="🔍 Search products..."
      />

      <Link to="/cart" className="cartbtn">
        🛒 Cart
      </Link>
    </nav>
  );
}

export default Navbar;