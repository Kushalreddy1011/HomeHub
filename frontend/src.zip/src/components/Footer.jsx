function Footer(){
return(
<footer className="footer">

<h2>🏠 HomeHub</h2>

<p>Furniture | Kitchen | Electronics</p>

<p>Phone : +91 9876543210</p>

<p>Email : support@homehub.com</p>

<p>©2026 HomeHub</p>

</footer>
)
}

export default Footer;