function Checkout() {
  return (
    <div style={{ padding: "40px" }}>
      <h1>Checkout</h1>

      <input placeholder="Full Name" /><br /><br />

      <input placeholder="Phone Number" /><br /><br />

      <textarea placeholder="Delivery Address"></textarea>

      <br /><br />

      <select>
        <option>Cash On Delivery</option>
        <option>PhonePe (Demo)</option>
      </select>

      <br /><br />

      <button
        style={{
          background: "#2563eb",
          color: "white",
          padding: "15px 40px",
          border: "none",
          borderRadius: "8px",
        }}
      >
        Place Order
      </button>
    </div>
  );
}

export default Checkout;