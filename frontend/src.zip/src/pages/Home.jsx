import { useEffect, useState } from "react";
import api from "../services/api";
import ProductCard from "../components/ProductCard";

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    api.get("products/").then((res) => setProducts(res.data));
  }, []);

  const furniture = products.filter(
    (p) => p.category === "Furniture"
  );

  const kitchen = products.filter(
    (p) => p.category === "Kitchen"
  );

  const electronics = products.filter(
    (p) => p.category === "Electronics"
  );

  return (
    <div>

      {/* HERO SECTION */}

      <section className="hero">

        <div className="overlay">

          <h1>Welcome to HomeHub</h1>

          <p>
            Modern Furniture • Kitchen Essentials • Electronics
          </p>

          <a href="#products">
            <button>Shop Now</button>
          </a>

        </div>

      </section>

      {/* FEATURES */}

      <section className="features">

        <div className="feature">
          🚚
          <h3>Free Delivery</h3>
        </div>

        <div className="feature">
          💳
          <h3>Secure Payment</h3>
        </div>

        <div className="feature">
          ⭐
          <h3>Premium Quality</h3>
        </div>

        <div className="feature">
          🔄
          <h3>Easy Returns</h3>
        </div>

      </section>

      <div id="products">

        <section className="section">

          <h2>🛋 Furniture</h2>

          <div className="grid">
            {furniture.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>

        </section>

        <section className="section">

          <h2>🍳 Kitchen</h2>

          <div className="grid">
            {kitchen.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>

        </section>

        <section className="section">

          <h2>💻 Electronics</h2>

          <div className="grid">
            {electronics.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>

        </section>

      </div>

    </div>
  );
}
